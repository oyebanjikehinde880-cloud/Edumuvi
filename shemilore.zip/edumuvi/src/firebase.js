// Import the functions you need from the SDKs
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCbLqH80ErVa474ToHzL7mPNXHbgTgpTNs",
  authDomain: "edumuvi-ec332.firebaseapp.com",
  projectId: "edumuvi-ec332",
  storageBucket: "edumuvi-ec332.firebasestorage.app",
  messagingSenderId: "509806032551",
  appId: "1:509806032551:web:96695c8deae4d1311b8d82"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);