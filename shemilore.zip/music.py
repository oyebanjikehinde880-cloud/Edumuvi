const btn=document.getElementById("generateSong");

btn.onclick=async()=>{

const topic=document.getElementById("topic").value;
const style=document.getElementById("style").value;

if(topic==""){
alert("Enter a topic");
return;
}

document.getElementById("lyrics").innerHTML="Generating...";

const response=await fetch("YOUR_API_URL",{

method:"POST",

headers:{

"Content-Type":"application/json",

"Authorization":"Bearer YOUR_API_KEY"

},

body:JSON.stringify({

topic:topic,

style:style

})

});

const data=await response.json();

document.getElementById("lyrics").innerHTML=data.lyrics;

document.getElementById("player").src=data.audio;

}