const topicInput = document.getElementById("topic");
const styleSelect = document.getElementById("style");
const generateBtn = document.getElementById("generateSong");
const loading = document.getElementById("loading");
const lyricsBox = document.getElementById("lyrics");
const player = document.getElementById("player");

generateBtn.addEventListener("click", generateSong);

async function generateSong() {

    const topic = topicInput.value.trim();
    const style = styleSelect.value;

    if(topic === ""){
        alert("Please enter a topic.");
        return;
    }

    loading.style.display = "block";
    lyricsBox.textContent = "Generating educational song...";
    player.removeAttribute("src");

    try{

        const response = await fetch("http://127.0.0.1:8000/generate",{

            method:"POST",

            headers:{
                "Content-Type":"application/json"
            },

            body:JSON.stringify({
                topic:topic,
                style:style
            })

        });

        const data = await response.json();

        lyricsBox.textContent = data.lyrics;

        if(data.audio){
            player.src = data.audio;
            player.load();
        }

    }catch(error){

        lyricsBox.textContent =
        "Error connecting to EduMusic AI backend.";

        console.log(error);

    }

    loading.style.display = "none";

}